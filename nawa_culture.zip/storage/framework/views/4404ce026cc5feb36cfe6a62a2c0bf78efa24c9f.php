<?php $__env->startSection('content'); ?>

<main>

    <?php if(session('msg')): ?>
        <div class="alert alert-<?php echo e(session('type')); ?>">
            <?php echo e(session('msg')); ?>

        </div>
    <?php endif; ?>

    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8 text-center">
                <img class="w-100 event-single-img mb-5" src="<?php echo e(asset('uploads/'.$project->image)); ?>" alt="">

                <h1><?php echo e($project->title); ?></h1>
                <h4><?php echo e($project->target); ?>$ - <?php echo e($project->donations->sum('amount')); ?>$</h4>

                <?php
                    $p = ($project->donations->sum('amount') / $project->target) * 100;
                    $p = round($p, 2);
                ?>

                <div class="progress">
                    <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo e($p); ?>%;" aria-valuenow="<?php echo e($p); ?>" aria-valuemin="0" aria-valuemax="100"><?php echo e($p); ?>%</div>
                  </div>
            </div>

            <div class="col-md-12 mt-5">
                <p><?php echo e($project->content); ?></p>
            </div>

            <div class="col-md-6 mt-5">

                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <?php if($p <= 100): ?>
                <h2>Donate</h2>
                <form action="<?php echo e(route('website.donation', $project->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label>Amount</label>
                        <input type="number" class="form-control" name="amount" placeholder="Amount" />
                    </div>
                  <button class="btn btn-primary w-100">Donate</button>
                </form>
                <?php endif; ?>

            </div>

        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nawa_culture\resources\views/website/project-single.blade.php ENDPATH**/ ?>