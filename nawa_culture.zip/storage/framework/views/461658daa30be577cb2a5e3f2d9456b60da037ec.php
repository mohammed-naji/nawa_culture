<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>Edit News : <span class="text-danger"><?php echo e($news->title); ?></span></h1>

    <a href="<?php echo e(route('admin.news.index')); ?>" class="btn btn-outline-dark">Return Back</a>
</div>

<?php echo $__env->make('admin.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('admin.news.update', $news->id)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>

            <div class="mb-3">
                <label>Title</label>
                <input type="text" class="form-control" value="<?php echo e(old('title', $news->title)); ?>" placeholder="Title" name="title" />
            </div>

            <div class="mb-3">
                <label>Image</label>
                <input class="form-control" type="file" name="image" />
                
                    <img class="mt-1 img-thumbnail" width="200" src="<?php echo e(asset('uploads/'.$news->image)); ?>" alt="">
                
            </div>

            <div class="mb-3">
                <label>Excerpt</label>
                <textarea class="form-control" placeholder="Excerpt" name="excerpt" rows="4"><?php echo e(old('excerpt', $news->excerpt)); ?></textarea>
            </div>

            <div class="mb-3">
                <label>Content</label>
                <textarea class="form-control" placeholder="Content" name="content" rows="7"><?php echo e(old('content', $news->content)); ?></textarea>
            </div>

            <button class="btn btn-primary px-5">Update</button>

        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nawa_culture\resources\views/admin/news/edit.blade.php ENDPATH**/ ?>