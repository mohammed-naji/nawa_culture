<?php if(session('msg')): ?>

<div class="alert alert-<?php echo e(session('type')); ?> alert-dismissible fade show" role="alert">

    <?php echo e(session('msg')); ?>


    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>

<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\nawa_culture\resources\views/admin/message.blade.php ENDPATH**/ ?>