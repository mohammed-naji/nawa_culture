<h1 style="background: #753767; padding: 20px;color:#fff">There is new message with the follwing data</h1>

<p style="color: #20886e"><b>Name</b>: <span><?php echo e($data['name']); ?></span></p>
<p style="color: #ff419a"><b>Email</b>: <span><?php echo e($data['email']); ?></span></p>
<p style="color: #c0db45"><b>Subject</b>: <span><?php echo e($data['subject']); ?></span></p>
<p style="color: #73b3f3"><b>Message</b>: <span><?php echo e($data['message']); ?></span></p>
<?php /**PATH C:\xampp\htdocs\nawa_culture\resources\views/emails/contact.blade.php ENDPATH**/ ?>