<?php $__env->startSection('content'); ?>

<main>
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-6">

                <h1 class="mb-4 text-center">Thanks for your kindly donation</h1>
                <h4 class="mb-5 text-center">You will donate <b class="text-danger">(<?php echo e($amount); ?>$)</b> for <b class="text-danger">(<?php echo e($project->title); ?>)</b></h4>

                <script src="https://eu-test.oppwa.com/v1/paymentWidgets.js?checkoutId=<?php echo e($checkoutId); ?>"></script>

                <form action="<?php echo e(route('website.donation_result', $project->id)); ?>" class="paymentWidgets" data-brands="VISA MASTER AMEX MADA"></form>



            </div>
        </div>

    </div>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nawa_culture\resources\views/website/donation.blade.php ENDPATH**/ ?>