<?php $__env->startSection('content'); ?>

<main>
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8 text-center">
                <img class="w-100 event-single-img mb-5" src="<?php echo e(asset('uploads/'.$event->image)); ?>" alt="">

                <h1><?php echo e($event->title); ?></h1>
                <h4><?php echo e($event->start_date); ?> - <?php echo e($event->end_date); ?></h4>

            </div>

            <div class="col-md-12 mt-5">
                <p><?php echo e($event->content); ?></p>
            </div>

            <div class="col-md-6 mt-5">

                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <h2>Enroll in this event</h2>
                <form action="<?php echo e(route('website.enrolled', $event->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3">
                        <label>Name</label>
                        <input class="form-control" name="name" placeholder="Name" />
                    </div>
                    <div class="mb-3">
                      <label>Mobile</label>
                      <input class="form-control" name="mobile" placeholder="Mobile" />
                  </div>
                  <button class="btn btn-primary w-100">Enroll</button>
                </form>
            </div>

        </div>
    </div>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nawa_culture\resources\views/website/event-single.blade.php ENDPATH**/ ?>