<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>All Events Registrations</h1>
</div>

<form class="mb-4" method="get" action="<?php echo e(route('admin.events.enrollments')); ?>">
    <div class="form-row align-items-center">
        <div class="col-5 my-1">
            <input type="text" value="<?php echo e(request()->name); ?>" name="name" class="form-control" placeholder="Name">
        </div>
      <div class="col-5 my-1">
        <select name="event" class="custom-select mr-sm-2">
          <option value="" selected>Choose...</option>
          <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option <?php echo e((request()->event == $event->id) ? 'selected' : '' ); ?> value="<?php echo e($event->id); ?>"><?php echo e($event->title); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-2 my-1">
        <button type="submit" class="btn btn-primary w-100">Search</button>
      </div>
    </div>
  </form>

<table class="table">
    <tr class="table-primary">
        <th>ID</th>
        <th>Name</th>
        <th>Mobile</th>
        <th>Event</th>
    </tr>

    <?php $__currentLoopData = $enrollments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enroll): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($enroll->id); ?></td>
        <td><?php echo e($enroll->name); ?></td>
        <td><?php echo e($enroll->mobile); ?></td>
        <td><?php echo e($enroll->event->title); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nawa_culture\resources\views/admin/events/enrollments.blade.php ENDPATH**/ ?>