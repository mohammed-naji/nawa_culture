<?php $__env->startSection('content'); ?>
<main>
    <div class="container my-5">
        <div class="row">
          <div class="col-md-6">
            <img src="<?php echo e(asset('uploads/'.$news->image)); ?>" class="w-100" alt="">
          </div>

          <div class="col-md-6">
            <h1><?php echo e($news->title); ?></h1>
            <span class="d-block mb-3"><?php echo e($news->created_at->format('d/m/Y')); ?></span>
            <p><?php echo e($news->content); ?></p>
          </div>

          <div class="col-md-12 mt-5">
            <h3>Comments (<?php echo e($news->comments->count()); ?>)</h3>

            <ul class="list-unstyled">
                <?php $__currentLoopData = $news->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <b><?php echo e($item->user->name); ?></b>
                    <small><?php echo e($item->created_at->format('d/m/Y')); ?></small>
                    <p><?php echo e($item->comment); ?></p>
                  </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>

            <h4>Leave Comment</h4>
            <?php if(auth()->guard()->check()): ?>
            <form method="POST" action="<?php echo e(route('website.comments', $news->id)); ?>">
                <?php echo csrf_field(); ?>

                <textarea name="comment" class="form-control mb-3" id="comment" rows="5"></textarea>
                <div class="text-end"><button class="btn btn-primary px-5">Post</button></div>
              </form>
            <?php endif; ?>

            <?php if(auth()->guard()->guest()): ?>
                <p>To add comment here you must login here <a href="<?php echo e(route('login')); ?>">Login</a>. You dont have account register here <a href="<?php echo e(route('register')); ?>">Resgister</a></p>
            <?php endif; ?>
          </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nawa_culture\resources\views/website/news-single.blade.php ENDPATH**/ ?>