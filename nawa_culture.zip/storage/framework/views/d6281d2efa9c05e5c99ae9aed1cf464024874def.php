<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h1>All donations <span class="text-danger">(<?php echo e($donations->sum('amount')); ?>$)</span> </h1>

</div>

<?php echo $__env->make('admin.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<table class="table">
    <tr class="table-primary">
        <th>ID</th>
        <th>Project</th>
        <th>Amount</th>
        <th>Donated At</th>
    </tr>

    <?php $__currentLoopData = $donations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($donation->id); ?></td>
        <td><?php echo e($donation->project->title); ?></td>
        <td><?php echo e($donation->amount); ?></td>
        <td><?php echo e($donation->created_at->diffForHumans()); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</table>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nawa_culture\resources\views/admin/projects/donations.blade.php ENDPATH**/ ?>